INSERT INTO app_center_visualizations  (json) 
SELECT json FROM Visualizer (
ON "cfilter_saradhi" PARTITION BY 1 
AsterFunction('cfilter') 
Title('pie') 
VizType('pie')
);